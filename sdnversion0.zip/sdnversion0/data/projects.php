<?php
/*|[{"name":"OpenDaylightApplications","username":"admin","path":"applications"},{"name":"FirewallApplication","username":"admin","path":"FirewallApplication"}]|*/
?>