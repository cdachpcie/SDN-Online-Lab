#DragDrop

Drag'n'Drop for Codiad filemanager

##Installation

- Download the zip file and unzip it to your plugin folder.

#New Features

Drag files to insert or append content to current active file. (Activate it in the settings)

![Screenshot](https://andrano.de/Plugins/img/dragdrop.png "Screenshot")