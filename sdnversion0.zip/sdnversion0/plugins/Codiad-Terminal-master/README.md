# Terminal Emulator

This plugin allows for interaction with the unix terminal through the [Codiad](http://www.codiad.com) user interface.

# Installation

- Download the zip file and extract it to your plugins folder
- Enable this plugin in the plugins manager in Codiad

# Usage

Simply open the terminal via it's entry in the right-hand menu. The default password is `terminal` which can 
be changed in `/emulator/term.php` in the `define('PASSWORD','terminal');`.
