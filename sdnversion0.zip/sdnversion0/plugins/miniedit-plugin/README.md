# Terminal Emulator

This plugin allows for interaction with the unix terminal through the [Codiad](http://www.codiad.com) user interface.

# Installation

- Download the zip file and extract it to your plugins folder
- Enable this plugin in the plugins manager in Codiad

# Usage
https://www.quora.com/How-do-I-run-Python-script-from-php
