# Add two numbers
num1 = 3
num2 = 2
sum = num1+num2
print "Addition of 2 numbers: %d + %d  = %d " % (num1, num2, sum) 

#str = 'Sum of ', num1 , 'and ', num2 , 'is:',sum;

