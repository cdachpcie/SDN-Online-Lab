# Macro

This plugin adds some kind of macro functionallity to Codiad

# Installation

- Download the zip file and extract it to your plugins folder
