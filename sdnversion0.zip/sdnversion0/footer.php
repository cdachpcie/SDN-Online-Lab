 <script src="components/editor/ace-editor/ace.js"></script>
  <script>
    var i18n = (function(lang) {
        return function(word,args) {
            var x;
            var returnw = (word in lang) ? lang[word] : word;
            for(x in args){
                returnw=returnw.replace("%{"+x+"}%",args[x]);   
            }
            return returnw;
        }
    })(<?php echo json_encode($lang); ?>)
    </script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script>!window.jQuery && document.write(unescape('%3Cscript src="js/jquery-1.7.2.min.js"%3E%3C/script%3E'));</script>
    <script src="js/jquery-ui-1.8.23.custom.min.js"></script>
    <script src="js/jquery.css3.min.js"></script>
    <script src="js/jquery.easing.js"></script>
    <script src="js/jquery.toastmessage.js"></script>
    <script src="js/amplify.min.js"></script>
    <script src="js/localstorage.js"></script>
    <script src="js/jquery.hoverIntent.min.js"></script>
    <script src="js/system.js"></script>
    <script src="js/sidebars.js"></script>
    <script src="js/modal.js"></script>
    <script src="js/message.js"></script>
    <script src="js/jsend.js"></script>
    <script src="js/instance.js?v=<?php echo time(); ?>"></script>

    <!-- COMPONENTS -->
    <?php

        require_once('common.php');


        $components = Common::readDirectory(COMPONENTS);
        $plugins = Common::readDirectory(PLUGINS);
        $themes = Common::readDirectory(THEMES);

        //////////////////////////////////////////////////////////////////
        // LOAD COMPONENTS
        //////////////////////////////////////////////////////////////////

        // JS
        foreach($components as $component){
            if(file_exists(COMPONENTS . "/" . $component . "/init.js")){
                echo('<script src="components/'.$component.'/init.js"></script>');
            }
        }
        
        foreach($plugins as $plugin){
            if(file_exists(PLUGINS . "/" . $plugin . "/init.js")){
                echo('<script src="plugins/'.$plugin.'/init.js"></script>');
            }
        }

    //}

    ?>

    <div class="footer">
                            
        <div class="col-xs-12 col-sm-6 col-md-6">
        <p class="footer-text"> &copy; 2017 All right reserved by C-DAC </p>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-6">
        <p class="footer-textr"> Design by WDG & Developed by MDEG (HPC I&amp;E )</p>
        </div>
    </div>