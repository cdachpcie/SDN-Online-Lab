<?php

/*
 *  (c) C-DAC
*/

require_once 'class.fileextension_textmode.php';

$fileExTM = new fileextension_textmode();


echo $fileExTM->processForms();
